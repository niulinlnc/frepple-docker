==========
Purchasing
==========

This module provides the functionality to purchase items from your suppliers.
The suppliers must be declared in the supplier tables and the items each supplier
can procure have to be declared in the item supplier table. 

.. toctree::
   :maxdepth: 2

   suppliers
   item-suppliers
   purchase-orders
