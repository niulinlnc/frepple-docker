r'''
A Django project implementing a web-based user interface for frePPLe.
'''
VERSION = '4.1'
