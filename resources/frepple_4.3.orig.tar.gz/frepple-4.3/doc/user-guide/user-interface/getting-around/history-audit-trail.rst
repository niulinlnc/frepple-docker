=====================
History – Audit trail
=====================

This screen shows the audit trail of all edits that have been performed on an
entity either a) in the user interface or b) by uploading a data file.

.. image:: ../_images/history-audit-trail.png
   :alt: Audit trail
