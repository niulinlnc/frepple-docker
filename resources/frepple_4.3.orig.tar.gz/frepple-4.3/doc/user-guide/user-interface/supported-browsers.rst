==================
Supported browsers
==================

The frePPLe user interface is browser based. 

The following web browsers are supported:

* **Google Chrome** 48 and higher.

* **Firefox** 45 and higher.

* **Microsoft Edge** 25 and higher.

* **Safari** 10.9 and higher.

Internet Explorer is NOT supported any longer.

For best results we recommend a high-resolution and wide screen. The
user interface isn't optimized for mobile devices (yet).
