==================
Inventory Planning
==================

.. Important::

   This functionality is only available in the Enterprise Edition.

This module provides the functionality to compute a safety stock and a reorder
quantity for your buffers.

.. toctree::
   :maxdepth: 2

   inventory-planning-parameters

