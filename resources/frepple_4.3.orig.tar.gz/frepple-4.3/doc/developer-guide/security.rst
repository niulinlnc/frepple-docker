========
Security
========

FrePPLe has been developed with a big focus on security of the 
application and its data.

If you find a security issue in the code, please report it with an
email to info@frepple.com rather than publishing it on the user forum
or filing a bug report.
