=============
Class diagram
=============

The diagrams below are also :download:`available in PDF format <../_images/classdiagram.pdf>`

.. image:: ../_images/classdiagram_model.png
   :alt: Class diagram - domain model classes

.. image:: ../_images/classdiagram_utils.png
   :alt: Class diagram - utility classes
